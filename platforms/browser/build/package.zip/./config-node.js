// This file is used to make additional changes
// when building an app to run in node.js.
// Free to edit. You can break tests (cli test runner uses
// this to build itself - it is a node executable).
define("amber/Platform", ["amber_core/Platform-Node"], {});
define("amber/browser-compatibility", {});
define("jquery", {});
