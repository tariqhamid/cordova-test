define("amber-ambercordova/AmberCordova-Tests", ["amber/boot", "amber_core/SUnit"], function($boot){"use strict";
var $core=$boot.api,nil=$boot.nil,$recv=$boot.asReceiver,$globals=$boot.globals;
$core.addPackage('AmberCordova-Tests');
$core.packages["AmberCordova-Tests"].innerEval = function (expr) { return eval(expr); };
$core.packages["AmberCordova-Tests"].transport = {"type":"amd","amdNamespace":"amber-ambercordova"};

$core.addClass('AmberCordovaTest', $globals.TestCase, [], 'AmberCordova-Tests');

});
