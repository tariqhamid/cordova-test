define("amber-ambercordova/Timer-Tests", ["amber/boot", "amber_core/SUnit"], function($boot){"use strict";
var $core=$boot.api,nil=$boot.nil,$recv=$boot.asReceiver,$globals=$boot.globals;
$core.addPackage('Timer-Tests');
$core.packages["Timer-Tests"].innerEval = function (expr) { return eval(expr); };
$core.packages["Timer-Tests"].transport = {"type":"amd","amdNamespace":"amber-ambercordova"};

$core.addClass('TimerTest', $globals.TestCase, [], 'Timer-Tests');

});
