define([
    'amber/deploy',
    // --- packages to be deployed begin here ---
    'amber-ambercordova/AmberCordova'
    // --- packages to be deployed end here ---
], function (amber) {
    return amber;
});
